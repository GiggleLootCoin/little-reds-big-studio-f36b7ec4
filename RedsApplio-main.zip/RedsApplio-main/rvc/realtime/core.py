import os
import sys
import time
import torch
import torch.nn.functional as F
import torchaudio.transforms as tat
import numpy as np
from noisereduce.torchgate import TorchGate
from pedalboard import (
    Pedalboard,
    Chorus,
    Distortion,
    Reverb,
    PitchShift,
    Limiter,
    Gain,
    Bitcrush,
    Clipping,
    Compressor,
    Delay,
)

now_dir = os.getcwd()
sys.path.append(now_dir)

from rvc.realtime.utils.torch import circular_write
from rvc.realtime.utils.vad import VADProcessor
from rvc.realtime.pipeline import create_pipeline

SAMPLE_RATE = 16000
AUDIO_SAMPLE_RATE = 48000


def phase_vocoder(a, b, fade_out, fade_in):
    """
    Performs a phase vocoder crossfade between two audio segments.

    This function blends segment `a` and segment `b` by aligning their phases
    in the frequency domain to prevent phase cancellation during the transition,
    while applying the provided fade-out and fade-in windows.

    Args:
        a (torch.Tensor): The first audio segment.
        b (torch.Tensor): The second audio segment.
        fade_out (torch.Tensor): The fade-out window applied to segment `a`.
        fade_in (torch.Tensor): The fade-in window applied to segment `b`.

    Returns:
        torch.Tensor: The crossfaded audio segment.
    """

    # Compute the analysis window as the geometric mean of fade curves
    window = (fade_out * fade_in).sqrt()
    # Transform both windowed segments to the frequency domain (Real FFT)
    fa = torch.fft.rfft(a * window)
    fb = torch.fft.rfft(b * window)
    # Calculate the combined magnitude spectrum
    absab = fa.abs() + fb.abs()
    n = a.shape[0]

    # Compensate for the energy of negative frequencies (except DC and Nyquist components)
    if n % 2 == 0:
        absab[1:-1] *= 2
    else:
        absab[1:] *= 2

    # Extract initial phase and calculate the raw phase difference
    phia = fa.angle()
    deltaphase = fb.angle() - phia

    # Reconstruct the signal using a combination of time-domain crossfade
    # and phase-aligned sinusoidal synthesis (Phase Vocoder)
    return (
        a * (fade_out**2)
        + b * (fade_in**2)
        + (
            absab
            * (
                (
                    # Base frequency grid for each bin
                    2 * torch.pi * torch.arange(n // 2 + 1).to(a)
                    +
                    # Phase unwrapping (wrapping delta phase to the [-pi, pi] range)
                    (
                        deltaphase
                        - 2 * torch.pi * (deltaphase / 2 / torch.pi + 0.5).floor()
                    )
                )
                * (torch.arange(n).unsqueeze(-1).to(a) / n)
                + phia  # Continuous phase evolution over time
            ).cos()
        ).sum(-1)
        * window
        / n  # Sum the sinusoidal components (IFFT equivalent) and normalize
    )


class Realtime:
    def __init__(
        self,
        model_path: str = None,
        index_path: str = None,
        f0_method: str = "rmvpe",
        embedder_model: str = None,
        embedder_model_custom: str = None,
        silent_threshold: int = 0,
        vad_enabled: bool = False,
        vad_sensitivity: int = 3,
        vad_frame_ms: int = 30,
        sid: int = 0,
        clean_audio: bool = False,
        clean_strength: float = 0.5,
        post_process: bool = False,
        **kwargs,
        # device: str = "cuda",
    ):
        self.sample_rate = SAMPLE_RATE
        self.convert_buffer = None
        self.pitch_buffer = None
        self.pitchf_buffer = None
        self.return_length = 0
        self.skip_head = 0
        self.silence_front = 0
        # Convert dB to RMS
        self.input_sensitivity = 10 ** (silent_threshold / 20)
        self.window_size = self.sample_rate // 100
        self.kwargs = None
        self.model_path = model_path
        self.index_path = index_path
        self.embedder_model = embedder_model
        self.embedder_model_custom = embedder_model_custom

        self.vad = (
            VADProcessor(
                sensitivity_mode=vad_sensitivity,
                sample_rate=self.sample_rate,
                frame_duration_ms=vad_frame_ms,
            )
            if vad_enabled
            else None
        )
        self.board = self.setup_pedalboard(**kwargs) if post_process else None
        # Create conversion pipelines
        self.pipeline = create_pipeline(
            model_path,
            index_path,
            f0_method,
            embedder_model,
            embedder_model_custom,
            # device,
            sid,
        )
        self.device = self.pipeline.device
        self.dtype = self.pipeline.dtype
        # noise reduce
        self.reduced_noise = (
            TorchGate(
                self.pipeline.tgt_sr,
                prop_decrease=clean_strength,
            ).to(self.device)
            if clean_audio
            else None
        )
        # Resampling of inputs and outputs.
        self.resample_in = tat.Resample(
            orig_freq=AUDIO_SAMPLE_RATE, new_freq=self.sample_rate, dtype=torch.float32
        ).to(self.device)
        self.resample_out = tat.Resample(
            orig_freq=self.pipeline.tgt_sr,
            new_freq=AUDIO_SAMPLE_RATE,
            dtype=torch.float32,
        ).to(self.device)

    def setup_pedalboard(self, **kwargs):
        board = Pedalboard()
        if kwargs.get("reverb", False):
            reverb = Reverb(
                room_size=kwargs.get("reverb_room_size", 0.5),
                damping=kwargs.get("reverb_damping", 0.5),
                wet_level=kwargs.get("reverb_wet_level", 0.33),
                dry_level=kwargs.get("reverb_dry_level", 0.4),
                width=kwargs.get("reverb_width", 1.0),
                freeze_mode=kwargs.get("reverb_freeze_mode", 0),
            )
            board.append(reverb)
        if kwargs.get("pitch_shift", False):
            pitch_shift = PitchShift(semitones=kwargs.get("pitch_shift_semitones", 0))
            board.append(pitch_shift)
        if kwargs.get("limiter", False):
            limiter = Limiter(
                threshold_db=kwargs.get("limiter_threshold", -6),
                release_ms=kwargs.get("limiter_release", 0.05),
            )
            board.append(limiter)
        if kwargs.get("gain", False):
            gain = Gain(gain_db=kwargs.get("gain_db", 0))
            board.append(gain)
        if kwargs.get("distortion", False):
            distortion = Distortion(drive_db=kwargs.get("distortion_gain", 25))
            board.append(distortion)
        if kwargs.get("chorus", False):
            chorus = Chorus(
                rate_hz=kwargs.get("chorus_rate", 1.0),
                depth=kwargs.get("chorus_depth", 0.25),
                centre_delay_ms=kwargs.get("chorus_delay", 7),
                feedback=kwargs.get("chorus_feedback", 0.0),
                mix=kwargs.get("chorus_mix", 0.5),
            )
            board.append(chorus)
        if kwargs.get("bitcrush", False):
            bitcrush = Bitcrush(bit_depth=kwargs.get("bitcrush_bit_depth", 8))
            board.append(bitcrush)
        if kwargs.get("clipping", False):
            clipping = Clipping(threshold_db=kwargs.get("clipping_threshold", 0))
            board.append(clipping)
        if kwargs.get("compressor", False):
            compressor = Compressor(
                threshold_db=kwargs.get("compressor_threshold", 0),
                ratio=kwargs.get("compressor_ratio", 1),
                attack_ms=kwargs.get("compressor_attack", 1.0),
                release_ms=kwargs.get("compressor_release", 100),
            )
            board.append(compressor)
        if kwargs.get("delay", False):
            delay = Delay(
                delay_seconds=kwargs.get("delay_seconds", 0.5),
                feedback=kwargs.get("delay_feedback", 0.0),
                mix=kwargs.get("delay_mix", 0.5),
            )
            board.append(delay)

        return board

    def realloc(
        self,
        block_frame: int,
        extra_frame: int,
        crossfade_frame: int,
        sola_search_frame: int,
    ):
        # Calculate frame sizes based on DEVICE sample rate (f.e., 48000Hz) and convert to 16000Hz
        block_frame_16k = int(block_frame / AUDIO_SAMPLE_RATE * self.sample_rate)
        crossfade_frame_16k = int(
            crossfade_frame / AUDIO_SAMPLE_RATE * self.sample_rate
        )
        sola_search_frame_16k = int(
            sola_search_frame / AUDIO_SAMPLE_RATE * self.sample_rate
        )
        extra_frame_16k = int(extra_frame / AUDIO_SAMPLE_RATE * self.sample_rate)

        convert_size_16k = (
            block_frame_16k
            + sola_search_frame_16k
            + extra_frame_16k
            + crossfade_frame_16k
        )
        if (
            modulo := convert_size_16k % self.window_size
        ) != 0:  # Compensate for truncation due to hop size in model output.
            convert_size_16k = convert_size_16k + (self.window_size - modulo)
        self.convert_feature_size_16k = convert_size_16k // self.window_size

        self.block_frame_16k = block_frame_16k
        self.skip_head = extra_frame_16k // self.window_size
        self.return_length = self.convert_feature_size_16k - self.skip_head
        self.silence_front = (
            extra_frame_16k - (self.window_size * 5) if self.silence_front else 0
        )
        # Number of blocks to fill convert_buffer before enabling model output.
        self.warmup_blocks = int(np.ceil(convert_size_16k / block_frame_16k)) + 1
        # Audio buffer to measure volume between chunks
        audio_buffer_size = block_frame_16k + crossfade_frame_16k
        self.audio_buffer = torch.zeros(
            audio_buffer_size, dtype=self.dtype, device=self.device
        )
        # Audio buffer for conversion without silence
        self.convert_buffer = torch.zeros(
            convert_size_16k, dtype=self.dtype, device=self.device
        )
        # Additional +1 is to compensate for pitch extraction algorithm
        # that can output additional feature.
        self.pitch_buffer = torch.zeros(
            self.convert_feature_size_16k + 1, dtype=torch.int64, device=self.device
        )
        self.pitchf_buffer = torch.zeros(
            self.convert_feature_size_16k + 1, dtype=self.dtype, device=self.device
        )

    def inference(
        self,
        audio_input: np.ndarray,
        f0_up_key: int = 0,
        index_rate: float = 0.5,
        protect: float = 0.5,
        volume_envelope: float = 1,
        f0_autotune: bool = False,
        f0_autotune_strength: float = 1,
        proposed_pitch: bool = False,
        proposed_pitch_threshold: float = 155.0,
    ):
        if self.pipeline is None:
            raise RuntimeError("Pipeline is not initialized.")

        # Input audio is always float32
        audio_input_16k = self.resample_in(
            torch.as_tensor(audio_input, dtype=torch.float32, device=self.device)
        ).to(self.dtype)
        circular_write(audio_input_16k, self.audio_buffer)

        vol_t = torch.sqrt(torch.square(self.audio_buffer).mean())
        vol = max(vol_t.item(), 0)

        board = self.board
        reduced_noise = self.reduced_noise

        # Fill convert_buffer with real audio, output zeros during warmup.
        if self.warmup_blocks > 0:
            self.warmup_blocks -= 1
            circular_write(audio_input_16k, self.convert_buffer)
            audio_model = self.pipeline.voice_conversion(
                self.convert_buffer,
                self.pitch_buffer,
                self.pitchf_buffer,
                f0_up_key,
                index_rate,
                self.convert_feature_size_16k,
                self.silence_front,
                self.skip_head,
                self.return_length,
                protect,
                volume_envelope,
                f0_autotune,
                f0_autotune_strength,
                proposed_pitch,
                proposed_pitch_threshold,
                reduced_noise,
                board,
                block_size_16k=self.block_frame_16k,
            )
            return (
                torch.zeros(audio_model.shape, dtype=torch.float32, device=self.device),
                vol,
                True,
            )

        if self.vad is not None:
            is_speech = self.vad.is_speech(audio_input_16k.cpu().numpy().copy())
            if not is_speech:
                # Busy wait to keep power manager happy and clocks stable. Running pipeline on-demand seems to lag when the delay between
                # voice changer activation is too high.
                # https://forums.developer.nvidia.com/t/why-kernel-calculate-speed-got-slower-after-waiting-for-a-while/221059/9
                audio_model = self.pipeline.voice_conversion(
                    self.convert_buffer,
                    self.pitch_buffer,
                    self.pitchf_buffer,
                    f0_up_key,
                    index_rate,
                    self.convert_feature_size_16k,
                    self.silence_front,
                    self.skip_head,
                    self.return_length,
                    protect,
                    volume_envelope,
                    f0_autotune,
                    f0_autotune_strength,
                    proposed_pitch,
                    proposed_pitch_threshold,
                    reduced_noise,
                    board,
                    block_size_16k=self.block_frame_16k,
                )

                return (
                    torch.zeros(
                        audio_model.shape, dtype=torch.float32, device=self.device
                    ),
                    vol,
                    True,
                )

        if vol < self.input_sensitivity:
            audio_model = self.pipeline.voice_conversion(
                self.convert_buffer,
                self.pitch_buffer,
                self.pitchf_buffer,
                f0_up_key,
                index_rate,
                self.convert_feature_size_16k,
                self.silence_front,
                self.skip_head,
                self.return_length,
                protect,
                volume_envelope,
                f0_autotune,
                f0_autotune_strength,
                proposed_pitch,
                proposed_pitch_threshold,
                reduced_noise,
                board,
                block_size_16k=self.block_frame_16k,
            )

            return (
                torch.zeros(audio_model.shape, dtype=torch.float32, device=self.device),
                vol,
                True,
            )

        circular_write(audio_input_16k, self.convert_buffer)

        audio_model = self.pipeline.voice_conversion(
            self.convert_buffer,
            self.pitch_buffer,
            self.pitchf_buffer,
            f0_up_key,
            index_rate,
            self.convert_feature_size_16k,
            self.silence_front,
            self.skip_head,
            self.return_length,
            protect,
            volume_envelope,
            f0_autotune,
            f0_autotune_strength,
            proposed_pitch,
            proposed_pitch_threshold,
            reduced_noise,
            board,
            block_size_16k=self.block_frame_16k,
        )

        # Scale output by the current input RMS to suppress residue during silence.
        audio_out: torch.Tensor = self.resample_out(audio_model * vol_t)
        return audio_out, vol, False

    def __del__(self):
        del self.pipeline


class VoiceChanger:
    def __init__(
        self,
        read_chunk_size: int,
        cross_fade_overlap_size: float,
        extra_convert_size: float,
        model_path: str = None,
        index_path: str = None,
        f0_method: str = "rmvpe",
        embedder_model: str = None,
        embedder_model_custom: str = None,
        silent_threshold: int = 0,
        vad_enabled: bool = False,
        vad_sensitivity: int = 3,
        vad_frame_ms: int = 30,
        sid: int = 0,
        clean_audio: bool = False,
        clean_strength: float = 0.5,
        post_process: bool = False,
        record_audio: bool = False,
        record_audio_path: str = None,
        export_format: str = "WAV",
        **kwargs,
        # device: str = "cuda",
    ):
        self.soundfile = None
        self.record_audio = record_audio
        self.record_audio_path = record_audio_path
        self.export_format = export_format
        self.block_frame = read_chunk_size * 128
        self.crossfade_frame = int(cross_fade_overlap_size * AUDIO_SAMPLE_RATE)
        self.extra_frame = int(extra_convert_size * AUDIO_SAMPLE_RATE)
        self.sola_search_frame = AUDIO_SAMPLE_RATE // 100
        self.sola_buffer = None
        self.vc_model = Realtime(
            model_path,
            index_path,
            f0_method,
            embedder_model,
            embedder_model_custom,
            silent_threshold,
            vad_enabled,
            vad_sensitivity,
            vad_frame_ms,
            sid,
            clean_audio,
            clean_strength,
            post_process,
            **kwargs,
            # device
        )
        self.device = self.vc_model.device
        self.vc_model.realloc(
            self.block_frame,
            self.extra_frame,
            self.crossfade_frame,
            self.sola_search_frame,
        )
        self.generate_strength()
        self.setup_soundfile_record()

    def generate_strength(self):
        self.fade_in_window: torch.Tensor = (
            torch.sin(
                0.5
                * np.pi
                * torch.linspace(
                    0.0,
                    1.0,
                    steps=self.crossfade_frame,
                    device=self.device,
                    dtype=torch.float32,
                )
            )
            ** 2
        )

        self.fade_out_window: torch.Tensor = 1 - self.fade_in_window
        self.sola_denominator_kernel = torch.ones(
            1, 1, self.crossfade_frame, device=self.device, dtype=torch.float32
        )
        # The size will change from the previous result, so the record will be deleted.
        self.sola_buffer = torch.zeros(
            self.crossfade_frame, device=self.device, dtype=torch.float32
        )

    def setup_soundfile_record(self):
        import soundfile as sf

        self.soundfile = (
            sf.SoundFile(
                self.record_audio_path,
                mode="w",
                samplerate=AUDIO_SAMPLE_RATE,
                channels=1,
                format=self.export_format.lower(),
            )
            if self.record_audio
            else None
        )

    def process_audio(
        self,
        audio_input: np.ndarray,
        f0_up_key: int = 0,
        index_rate: float = 0.5,
        protect: float = 0.5,
        volume_envelope: float = 1,
        f0_autotune: bool = False,
        f0_autotune_strength: float = 1,
        proposed_pitch: bool = False,
        proposed_pitch_threshold: float = 155.0,
        use_phase_vocoder: bool = True,
    ):
        block_size = audio_input.shape[0]

        audio, vol, is_silence = self.vc_model.inference(
            audio_input,
            f0_up_key,
            index_rate,
            protect,
            volume_envelope,
            f0_autotune,
            f0_autotune_strength,
            proposed_pitch,
            proposed_pitch_threshold,
        )

        if is_silence:
            # Clear sola_buffer and return zeros for silent input.
            self.sola_buffer.zero_()
            silence_output = np.zeros(block_size, dtype=np.float32)
            if self.record_audio and self.soundfile is not None:
                self.soundfile.write(silence_output)
            return silence_output, vol

        # Detect silence-to-speech transition for onset-aware fade-in.
        is_onset = not self.sola_buffer.any()

        conv_input = audio[
            None, None, : self.crossfade_frame + self.sola_search_frame
        ].float()
        cor_nom = F.conv1d(conv_input, self.sola_buffer[None, None, :])
        cor_den = torch.sqrt(
            F.conv1d(conv_input**2, self.sola_denominator_kernel) + 1e-8
        )
        sola_offset = torch.argmax(cor_nom[0, 0] / cor_den[0, 0])

        audio = audio[sola_offset:]

        if use_phase_vocoder:
            audio[: self.crossfade_frame] = phase_vocoder(
                self.sola_buffer,
                audio[: self.crossfade_frame],
                self.fade_out_window,
                self.fade_in_window,
            )
        else:
            if is_onset:
                # Find voice onset position and apply sin² fade-in, zeroing audio before onset.
                hop = 160  # ~3.3 ms at 48 kHz
                n_hops = block_size // hop
                if n_hops >= 1:
                    hop_energy = (
                        audio[: n_hops * hop]
                        .reshape(n_hops, hop)
                        .abs()
                        .max(dim=1)
                        .values
                    )
                    peak = hop_energy.max().item()
                    onset_sample = 0
                    if peak > 1e-4:
                        above = (hop_energy > 0.1 * peak).nonzero(as_tuple=False)
                        if len(above) > 0:
                            onset_sample = int(above[0].item()) * hop
                else:
                    onset_sample = 0
                audio[:onset_sample] = 0.0
                # Apply sin² fade-in over crossfade_frame duration from onset.
                fade_len = min(block_size - onset_sample, self.crossfade_frame)
                if fade_len > 0:
                    audio[
                        onset_sample : onset_sample + fade_len
                    ] *= self.fade_in_window[:fade_len]
            else:
                audio[: self.crossfade_frame] *= self.fade_in_window
                audio[: self.crossfade_frame] += self.sola_buffer * self.fade_out_window

        # Pad if audio is shorter than block_size + crossfade_frame.
        _need = block_size + self.crossfade_frame
        if audio.shape[0] < _need:
            pad = torch.zeros(
                _need - audio.shape[0], device=audio.device, dtype=audio.dtype
            )
            audio = torch.cat([audio, pad])
        self.sola_buffer[:] = audio[block_size : block_size + self.crossfade_frame]
        audio_output = audio[:block_size].detach().cpu().numpy()

        if self.record_audio and self.soundfile is not None:
            self.soundfile.write(audio_output)

        return audio_output, vol

    @torch.no_grad()
    def on_request(
        self,
        audio_input: np.ndarray,
        f0_up_key: int = 0,
        index_rate: float = 0.5,
        protect: float = 0.5,
        volume_envelope: float = 1,
        f0_autotune: bool = False,
        f0_autotune_strength: float = 1,
        proposed_pitch: bool = False,
        proposed_pitch_threshold: float = 155.0,
        use_phase_vocoder: bool = True,
    ):
        if self.vc_model is None:
            raise RuntimeError("Voice Changer is not selected.")

        start = (
            time.perf_counter()
        )  # Using perf_counter to measure real-time voice conversion latency.
        result, vol = self.process_audio(
            audio_input,
            f0_up_key,
            index_rate,
            protect,
            volume_envelope,
            f0_autotune,
            f0_autotune_strength,
            proposed_pitch,
            proposed_pitch_threshold,
            use_phase_vocoder,
        )
        end = time.perf_counter()

        return result, vol, [0, (end - start) * 1000, 0]
